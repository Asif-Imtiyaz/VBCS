define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class addButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.newEmpRow.id = Math.max(...$variables.empADP.data.map(obj => obj.id)) + 1;
      console.log("Max Id :" + Math.max(...$variables.empADP.data.map(obj => obj.id)));

      await Actions.fireDataProviderEvent(context, {
        target: $variables.empADP,
        add: {
          data: $variables.newEmpRow,
          keys: $variables.newEmpRow.id,
        },
      });
      let payload = {
        rowKey: $variables.newEmpRow.id
      };

      $variables.editRow = payload;

      $variables.scrollPosition = payload;

    }
  }

  return addButtonActionChain;
});
