define([], () => {
  'use strict';

  class PageModule {
  // Javascript Code to check form validation and highlight error if any
    validateGroup(id) {
      let tracker = document.getElementById(id);
      if (tracker.valid === "valid") {
      }
      else if (tracker.valid.startsWith("invalid")) {
        if (tracker.valid === "invalidHidden") {
          tracker.showMessages();
        }
        tracker.focusOn("@firstInvalidShown");
      }
      return tracker.valid;
    }
  }
  
  return PageModule;
});
